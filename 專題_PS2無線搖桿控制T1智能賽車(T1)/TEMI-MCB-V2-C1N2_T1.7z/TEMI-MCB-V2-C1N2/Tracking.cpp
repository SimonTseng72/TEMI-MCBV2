#include "Tracking.h"

/*****************************************************************************
*/
byte IRSensor;
byte lineCMD;
byte IRSensorL;
int8_t  LRrun;
int8_t  LRCheck;
//------
int TrackingSpeedN;
int TrackingSpeedH;
/*****************************************************************************
*/
void CheckZero(byte Check)
{
  for(byte i=0;i<200;i++) {
    ReadSensor();
    if(IRSensor & Check)  break;
    delay(10);
  }
}
//-----
void CheckCAM(byte Mask,byte Check)
{
  for(byte i=0;i<200;i++) {
    ReadSensor();
    if((IRSensor & Mask) ==  Check)break;
    delay(10);
  }
}
/*****************************************************************************
 * 
*/
void Tracking05A() {  
  ReadSensor();   // 讀IR Sensor狀態           
  if(IRSensorL != IRSensor)
  {    
    IRSensorL = IRSensor;
    lineCMD = (IRSensor >>1) & 0x07; 
    //----------------------------------------------------------------
    if (lineCMD == 0) {
       if( (IRSensor & 0x11 ) == 0 )  {  // 00000      
            if(LRrun == 'L')      {
              Motor.LeftForward(TrackingSpeedN); 
              CheckZero(0x07);
            }
            if(LRrun == 'R')      {
              Motor.RightForward(TrackingSpeedN); 
              CheckZero(0x1C);
            }     
            Motor.Stop(1);   
            LRrun ='0';
        }  else if(IRSensor & 0x01)   {  //  ?0001  
            Motor.LeftForward(TrackingSpeedN);
            //CheckCAM(0x03,0x02);  //CheckZero(0x02);
            LRrun = 'L';
        }  else  {                       //  10000  
            Motor.RightForward(TrackingSpeedN);
            //CheckCAM(0x18,0x08);  //CheckZero(0x08);
            LRrun = 'R';
        }     
    } 
    //----------------------------------------------------------------
    else if (lineCMD == 1) {
        if(IRSensor & 0x01 )
          Motor.LeftForward(TrackingSpeedN);    //  ?0011  // 快
        else                   
          //Motor.LeftForward(TrackingSpeedN);    //  ?0010  // 慢
          Motor.Forward(TrackingSpeedH,TrackingSpeedN);    //  ?0110        
        LRrun ='L';
    } //--------------------------
    else if (lineCMD == 3) {
      if(IRSensor & 0x01 )    {
          if(IRSensor & 0x10)    {
              Motor.Stop(true);   
              LRrun ='0';
          } else {
            Motor.LeftForward(TrackingSpeedN);    //  ?0111
            LRrun ='L';
          }
        }
        else {                    
          Motor.Forward(TrackingSpeedH,TrackingSpeedN);    //  ?0110        
          LRrun ='L';
        }
    } 
    //----------------------------------------------------------------
    else if (lineCMD == 4) {
        if(IRSensor & 0x10 )
           Motor.RightForward(TrackingSpeedN);    //  1100?
        else                    
           //Motor.RightForward(TrackingSpeedN);   //  0100?
           Motor.Forward(TrackingSpeedN,TrackingSpeedH);    //  0110?      
        LRrun ='R';
    } //--------------------------    
    else if (lineCMD == 6) {
      if(IRSensor & 0x10 ) {
          if(IRSensor & 0x01 ) {  // 11101
              Motor.Stop();   
              LRrun ='0';
          }  else  {              // 11100
              Motor.RightForward(TrackingSpeedH);  
              LRrun ='R';
          }
      } else  {
        Motor.Forward(TrackingSpeedN,TrackingSpeedH);    //  0110?      
        LRrun ='R';
      }      
    } 
    //----------------------------------------------------------------
    else if (lineCMD == 2) {
        Motor.Forward(TrackingSpeedH,TrackingSpeedH);    //  ?010?
       // LRrun ='0';    
    } //--------------------------
    else if (lineCMD == 5) {
        Motor.Forward(TrackingSpeedH,TrackingSpeedH);   //   ?101?
       // LRrun ='0';
    } 
    //----------------------------------------------------------------
    else { // if (lineCMD == 7) {            //
         Motor.Stop(1);                       //
         delay(100);                         //
         LRrun ='0';                         //        
    } 
    //----------------------------------------------------------------
  }  
}
