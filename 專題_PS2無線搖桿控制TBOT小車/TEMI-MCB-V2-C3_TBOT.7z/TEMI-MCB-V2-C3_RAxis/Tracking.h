#ifndef Tracking_h
#define Tracking_h
#include <Arduino.h>
#include "DCMotor.h"
//---------------------------------------------------------------
#define _BA   0
//---------------------------------------------------------------
extern byte IRSensor;
extern byte IRSensorL;
extern DCMotor Motor;
extern int TrackingSpeedN;
extern int TrackingSpeedH;
//---------------------------------------------------------------
void ReadSensor();
void Tracking05A();  // 5 Sensor
//---------------------------------------------------------------
#endif
